#!/bin/sh

# Helper script with a familiar name to run auto* on a development tree.
sh `dirname $0`/build_posix/reconf
